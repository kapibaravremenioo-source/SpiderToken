// Small helper to reduce the chance of browsers/password-managers
// immediately re-populating fields after the user clears them.
// It randomizes the input 'name' and sets autocomplete off when the user
// actively clears a field (via Backspace/Delete or manual delete).
// This is a pragmatic, low-risk mitigation — browser behavior varies and
// no solution is 100% across all password managers.
(function () {
  'use strict';

  function randomizeName(el) {
    try {
      el.setAttribute('autocomplete', 'off');
      // change name so the browser won't match saved credentials
      el.setAttribute('name', 'no_' + Math.random().toString(36).slice(2));
      el.dataset.autofillBlocked = '1';
    } catch (e) {
      // ignore
    }
  }

  // When user presses backspace/delete and the field becomes empty,
  // mark it as user-cleared and randomize its name shortly after.
  document.addEventListener('keydown', function (ev) {
    var el = ev.target;
    if (!el || !el.tagName) return;
    var tag = el.tagName.toLowerCase();
    if (tag !== 'input' && tag !== 'textarea') return;

    if (ev.key === 'Backspace' || ev.key === 'Delete') {
      // use a short timeout to allow the value change to happen
      setTimeout(function () {
        if (el.value === '') {
          el.dataset.userCleared = '1';
          randomizeName(el);
        }
      }, 10);
    }
  }, true);

  // Also listen for input events (e.g. clear via mouse selection + delete)
  document.addEventListener('input', function (ev) {
    var el = ev.target;
    if (!el || !el.tagName) return;
    var tag = el.tagName.toLowerCase();
    if (tag !== 'input' && tag !== 'textarea') return;

    if (el.value === '') {
      el.dataset.userCleared = '1';
      randomizeName(el);
    }
  }, true);

  // On focus, if we previously marked the field as user-cleared, keep it
  // randomized so password managers don't re-match by name.
  document.addEventListener('focusin', function (ev) {
    var el = ev.target;
    if (!el || !el.tagName) return;
    var tag = el.tagName.toLowerCase();
    if (tag !== 'input' && tag !== 'textarea') return;

    if (el.dataset.userCleared === '1' && !el.dataset.autofillBlocked) {
      randomizeName(el);
    }
  });

  // As a fallback, on DOMContentLoaded, ensure login/register forms have
  // autocomplete attributes set conservatively to avoid aggressive autofill.
  document.addEventListener('DOMContentLoaded', function () {
    var selectors = 'form, input[autocomplete], input[type=email], input[type=password]';
    var els = document.querySelectorAll(selectors);
    els.forEach(function (el) {
      try {
        if (el.tagName.toLowerCase() === 'form') {
          el.setAttribute('autocomplete', 'off');
        } else if (el.tagName.toLowerCase() === 'input') {
          // If browser understands 'new-password' or 'off', prefer those
          if (el.type === 'password') el.setAttribute('autocomplete', 'new-password');
          else if (!el.hasAttribute('autocomplete')) el.setAttribute('autocomplete', 'off');
        }
      } catch (e) { }
    });
  });

})();
