// Dropdown functionality for the application

// ── Filter dropdown event delegation ──
// Handles item selection in Bootstrap custom dropdowns rendered by BaseDropdown RenderTemplate().
// On click: sets the hidden input value, strips empty params, submits the form.
function initFilterDropdowns() {
    document.addEventListener('click', function (e) {
        const item = e.target.closest('.filter-dropdown-menu [data-value]');
        if (!item) return;

        e.preventDefault();

        const group = item.closest('.filter-group');
        if (!group) return;

        const form = group.querySelector('.filter-form');
        const hiddenInput = form?.querySelector('.filter-hidden-value');
        if (!form || !hiddenInput) return;

        hiddenInput.value = item.dataset.value;

        // Update the visible button text
        const btn = group.querySelector('.filter-dropdown-text');
        if (btn) {
            btn.textContent = item.textContent.trim();
        }

        // Mark the active item
        group.querySelectorAll('.filter-dropdown-menu .dropdown-item').forEach(function (el) {
            el.classList.remove('active');
        });
        item.classList.add('active');

        // Strip empty params and submit
        handleDropdownSubmit(form, hiddenInput.name);
        form.submit();
    });
}

// Register on DOMContentLoaded and on Blazor enhanced navigation
document.addEventListener('DOMContentLoaded', initFilterDropdowns);

/**
 * Handles dropdown form submission and removes empty query parameters.
 * Supports both hidden-input (Bootstrap dropdown) and native select patterns.
 * @param {HTMLFormElement} form - The form element
 * @param {string} paramName - The parameter name to check
 * @returns {boolean} - Always returns true to allow submission
 */
function handleDropdownSubmit(form, paramName) {
    // Try hidden input first (Bootstrap custom dropdown pattern)
    var hiddenInput = form.querySelector('input.filter-hidden-value[name="' + paramName + '"]');
    if (hiddenInput) {
        var val = hiddenInput.value;
        if (!val || val === '' || val === 'null') {
            hiddenInput.removeAttribute('name');
            setTimeout(function () { hiddenInput.setAttribute('name', paramName); }, 100);
        }
        return true;
    }

    // Fallback: native select element
    var select = form.querySelector('select[name="' + paramName + '"]');
    if (!select) return true;

    var value = select.value;
    if (!value || value === '' || value === 'null') {
        var legacyHidden = form.querySelector('input[type="hidden"][name="' + paramName + '"]');
        if (legacyHidden) legacyHidden.remove();

        select.removeAttribute('name');
        setTimeout(function () { select.setAttribute('name', paramName); }, 100);
    }
    
    return true; // Allow form submission
}